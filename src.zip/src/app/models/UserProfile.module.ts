export class UserProfile {
    userId:any;
    token:any
}