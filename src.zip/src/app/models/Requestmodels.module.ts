export class Requestmodels{
    RequestUrl:any
    RequestObject:any
}